import TestComponent from '@components/Test/TestComponent';
import React from 'react';

const page = () => {
  return (
    <div>
      <TestComponent />
    </div>
  );
};

export default page;

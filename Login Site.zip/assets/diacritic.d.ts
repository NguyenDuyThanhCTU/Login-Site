declare module 'file-saver';
declare module 'xlsx-populate';
declare module 'negotiator';

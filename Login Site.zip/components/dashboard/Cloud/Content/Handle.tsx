import React from 'react';

const Handle = () => {
  return <div>Handle</div>;
};

export default Handle;

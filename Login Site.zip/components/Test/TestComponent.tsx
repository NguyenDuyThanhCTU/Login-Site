'use client';
import InputForm from '@components/dashboard/items/UI/InputForm';
import { useStateProvider } from '@context/StateProvider';
import React from 'react';

const TestComponent = () => {
  const { isLoading, setIsLoading } = useStateProvider();
  setTimeout(() => {
    setIsLoading(false);
  }, 5000);
  return (
    <div className="grid grid-cols-3">
      <div onClick={() => setIsLoading(1000)}>Loading....</div>
      <div onClick={() => setIsLoading(true)}>start</div>
    </div>
  );
};

export default TestComponent;
